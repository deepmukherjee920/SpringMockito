package com.springMokito.service;

import com.springMokito.dao.StudentDAO;
import com.springMokito.user.Student;

public class StudentService {
	
	StudentDAO studentDAO;
	
	public StudentService(StudentDAO studentDAO) {
		this.studentDAO = studentDAO;
	}
	
	public int saveStudent(Student student) {
		
		int id = studentDAO.save(student);
		return id;
	}

}
