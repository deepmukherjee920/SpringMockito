package com.springMokito.resource;

import com.springMokito.service.StudentService;
import com.springMokito.user.Student;

public class StudentResource {

	StudentService studentService;
	
	public StudentResource(StudentService studentService) {
		this.studentService = studentService;
	}
	
	public int saveStudent(String name, int age, String address) {
		Student student = new Student(name, age, address);
		int studentId = studentService.saveStudent(student);
		return studentId;
	}
}
