package com.springMokito.dao;

import java.util.HashMap;
import java.util.Map;

import com.springMokito.user.Student;

public class StudentDAO {

	static int i = 1;
	Map<Integer, Student> studentData = new HashMap<Integer, Student>();
	public int save(Student student) {
		studentData.put(i, student);
		i++;
		return i;
	}

}
