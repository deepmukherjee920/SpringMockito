package com.springMokito;

import org.mockito.Mockito;

import com.springMokito.resource.StudentResource;
import com.springMokito.service.StudentService;
import com.springMokito.user.Student;

public class StudentResourceTest {

	StudentResource studentResource;
	StudentService studentService;
	
	public static void main(String[] args) {
		StudentResourceTest resourceTest = new StudentResourceTest();
		resourceTest.setup();
		resourceTest.shouldSaveStudent();
		
	}

	private void setup() {


		studentService = Mockito.mock(StudentService.class);
		studentResource = new StudentResource(studentService);
		
	}

	private void shouldSaveStudent() {
		
		Student student = new Student("Deep", 23, "Kolkata, West bengal");
		Mockito.when(studentService.saveStudent(student)).thenReturn(1);
		int res = studentResource.saveStudent("Deep", 23, "Kolkata, West bengal");
		
		if(res == 1) {
			System.out.println("Test Case Passed Successfully");
		}
		else System.out.println("Test Case Failed, Check Carefully");
		
	}
}
