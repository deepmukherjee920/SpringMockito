package com.MockitoJunit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
//import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;

import com.MockitoJunit.resource.StudentResource;
import com.MockitoJunit.service.StudentService;
import com.MockitoJunit.user.Student;

@RunWith(MockitoJUnitRunner.class)
public class StudentResourceTest {

//	@Rule
//	public MockitoRule initRule = MockitoJUnit.rule();
	
	
	@Mock
	private StudentService studentService;
	private StudentResource studentResource;
	
	@Before
	private void setup() {
		
		System.out.println("hii deep");
		studentResource = new StudentResource(studentService);
		
	}
	
	@Test
	private void shouldSaveStudent() {
		
		Student student = new Student("Deep", 23, "Kolkata, West bengal");
		Mockito.when(studentService.saveStudent(student)).thenReturn(1);
		int res = studentResource.saveStudent("Deep", 23, "Kolkata, West bengal");
//		System.out.println("Hii");
		Assert.assertEquals(1, res);
		
		
	}
}
