package com.MockitoJunit.DAO;

import java.util.HashMap;
import java.util.Map;

import com.MockitoJunit.user.Student;


public class StudentDAO {

	static int i = 1;
	Map<Integer, Student> studentData = new HashMap<Integer, Student>();
	public int save(Student student) {
		studentData.put(i, student);
		i++;
		return i;
	}

}
