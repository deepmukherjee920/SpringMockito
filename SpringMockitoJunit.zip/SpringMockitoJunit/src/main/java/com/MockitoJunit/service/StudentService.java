package com.MockitoJunit.service;

import com.MockitoJunit.DAO.StudentDAO;
import com.MockitoJunit.user.Student;

public class StudentService {
	
	StudentDAO studentDAO;
	
	public StudentService(StudentDAO studentDAO) {
		this.studentDAO = studentDAO;
	}
	
	public int saveStudent(Student student) {
		
		int count = studentDAO.save(student);
		return count;
	}

}
